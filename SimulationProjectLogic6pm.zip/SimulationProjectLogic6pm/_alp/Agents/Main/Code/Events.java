void event()
{/*ALCODESTART::1777921026563*/
int hour = getHourOfDay();
int day = getDayOfWeek();
boolean isOpenNow;

if (day == FRIDAY || day == SATURDAY) {
    isOpenNow = (hour >= 11 && hour < 23);
} else {
    isOpenNow = (hour >= 11 && hour < 22);
}

if (isOpenNow && !wasOpen) {
    openTime = time();
    dailyBusyTime = 0; // reset for new day
}

if (!isOpenNow && wasOpen) {
    double hoursOpen = time() - openTime;
    int dayIndex = day - 1;
    dailyUtilization[dayIndex] = dailyBusyTime / (hoursOpen * pServers);
    traceln("Day=" + dayIndex + " util=" + dailyUtilization[dayIndex]);
    dailyBusyTime = 0;
}
wasOpen = isOpenNow;


if (isOpenNow) {
    seatingQueueData.add(time(), (queue3.statsSize.mean() + queue4.statsSize.mean() + 
        queue5.statsSize.mean() + queue6.statsSize.mean() + queue7.statsSize.mean() + 
        queue8.statsSize.mean() + queue9.statsSize.mean()) / 7.0);
    
    foodQueueData.add(time(), WaitForFood.statsSize.mean());
    paymentQueueData.add(time(), waitForPayment.statsSize.mean());
}
/*ALCODEEND*/}

