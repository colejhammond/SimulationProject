boolean isOpen()
{/*ALCODESTART::1777910574107*/
double currentTime = time() % (24 * 60); // minutes since midnight
int day = getDayOfWeek();

if (day == FRIDAY || day == SATURDAY) {
    return (currentTime >= 660 && currentTime < 1380); // 11AM to 11PM
} else {
    return (currentTime >= 660 && currentTime < 1320); // 11AM to 10PM
}
/*ALCODEEND*/}

